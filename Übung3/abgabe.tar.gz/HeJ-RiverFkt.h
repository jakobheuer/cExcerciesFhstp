// Heigl-Auer Jakob
// HeJ-RiverFkt.h

#ifndef __Jakob_h__
#define __Jakob_h__

int HeJ_digitsum(int);
int HeJ_NextRiverNum(int);

#endif