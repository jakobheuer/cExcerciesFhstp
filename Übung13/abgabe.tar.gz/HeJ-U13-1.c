// Jakob Heigl-Auer, Uebung13 - Aufgabe 1
// HeJ-U13-1.c

// Includes
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <stdbool.h>

//Deklarationen
int main(int argc, char *argv[])
{
    if(argc==1) //Stdin to stdout
    {

    }
    else if(argc==2) //File to stdout
    {

    }
    else if(argc==3) //File to file
    {

    }

    return 0;
}